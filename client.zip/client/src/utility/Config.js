const Config = {
  envName: 'main',
  ledgerUrl: 'http://localhost:3636/api/',
  authUrl: 'http://localhost:3636/api/',
  // ledgerUrl: 'http://localhost:3636/api/',
  user: 'hr_hovercraft',
  pass: 'Admin@#12345$938@123%',
  key: '345n3b4mn5',
};

export default Config;
